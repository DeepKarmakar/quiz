(function(){

	angular
		.module("turtleFacts")
		.controller("quizCtrl", quizController);

		quizController.$inject = ['DataService'];

		function quizController(DataService){
			var vm = this;
			vm.dataService = DataService;
			vm.activeQuestion = 0;
			vm.questionAnswerd = questionAnswerd;
			vm.setActiveQuestion = setActiveQuestion;

			var numQuestionAnswered =0;

			function setActiveQuestion(){
				var brekOut = false;
				var quizLength = DataService.quizQuestions.length - 1;  
				while(!brekOut){
					vm.activeQuestion = vm.activeQuestion < quizLength?++vm.activeQuestion:0;
					if (DataService.quizQuestions[vm.activeQuestion].selected === null) {
						brekOut = true;
					}
				}

			}

			function questionAnswerd(){
				var quizLength = DataService.quizQuestions.length;  
				if (DataService.quizQuestions[vm.activeQuestion].selected !== null) {
					numQuestionAnswered++;
					if (numQuestionAnswered >= quizLength) {
						// finalise Quiz
					}
				}
 
				vm.setActiveQuestion();
			}
		}; 

})();